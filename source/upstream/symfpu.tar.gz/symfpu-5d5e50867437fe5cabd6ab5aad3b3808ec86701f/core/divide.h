/* Part of SymFPU, see LICENSE for licensing information */
/*
** divide.h
**
** Martin Brain
** martin.brain@cs.ox.ac.uk
** 04/02/16
**
** Division of arbitrary precision floats
**
*/

#include "symfpu/core/unpackedFloat.h"
#include "symfpu/core/ite.h"
#include "symfpu/core/rounder.h"
#include "symfpu/core/operations.h"

#ifndef SYMFPU_DIVIDE
#define SYMFPU_DIVIDE

namespace symfpu {

template <class t>
  unpackedFloat<t> addDivideSpecialCases (const typename t::fpt &format,
					  const unpackedFloat<t> &left,
					  const unpackedFloat<t> &right,
					  const typename t::prop &sign,
					  const unpackedFloat<t> &divideResult) {
  typedef typename t::prop prop;

  prop eitherArgumentNaN(left.getNaN() || right.getNaN());
  prop generateNaN((left.getInf() && right.getInf()) ||
		   (left.getZero() && right.getZero()));
  
  prop isNaN(eitherArgumentNaN || generateNaN);

  prop isInf((!left.getZero() && right.getZero()) ||
	     (left.getInf() && !right.getInf()));

  prop isZero((!left.getInf() && right.getInf()) ||
	      (left.getZero() && !right.getZero()));

  return ITE(isNaN,
	     unpackedFloat<t>::makeNaN(format),
	     ITE(isInf,
		 unpackedFloat<t>::makeInf(format, sign),
		 ITE(isZero,
		     unpackedFloat<t>::makeZero(format, sign),
		     divideResult)));
 }

template <class t>
  floatWithStatusFlags<t> addDivideSpecialCases_flagged (const typename t::fpt &format,
					  const unpackedFloat<t> &left,
					  const unpackedFloat<t> &right,
					  const typename t::prop &sign,
					  const floatWithStatusFlags<t> &divideResult) {
  typedef typename t::prop prop;

  prop eitherArgumentNaN(left.getNaN() || right.getNaN());
  prop generateNaN((left.getInf() && right.getInf()) ||
		   (left.getZero() && right.getZero()));
  
  prop isNaN(eitherArgumentNaN || generateNaN);

  prop divZero(!left.getZero() && !left.getInf() && right.getZero());

  prop isInf(left.getInf() && !right.getInf());

  prop isZero((!left.getInf() && right.getInf()) ||
	      (left.getZero() && !right.getZero()));

  return ITE(isNaN,
    floatWithStatusFlags<t>::makeNaN(format, generateNaN),
    ITE(divZero,
      floatWithStatusFlags<t>::makeDivZero(format, sign),
      ITE(isInf,
        floatWithStatusFlags<t>::makeInf(format, sign),
        ITE(isZero,
          floatWithStatusFlags<t>::makeZero(format, sign),
          divideResult))));
 }


 template <class t>
  unpackedFloat<t> arithmeticDivide (const typename t::fpt &format,
				       const unpackedFloat<t> &left,
				       const unpackedFloat<t> &right) {
  typedef typename t::bwt bwt;
  typedef typename t::prop prop;
  typedef typename t::ubv ubv;
  typedef typename t::sbv sbv;
  //typedef typename t::fpt fpt;

  PRECONDITION(left.valid(format));
  PRECONDITION(right.valid(format));

  // Compute sign
  prop divideSign(left.getSign() ^ right.getSign());

  // Divide the significands
  // We need significandWidth() + 1 bits in the result but the top one may cancel, so add two bits
  ubv extendedNumerator(left.getSignificand().append(ubv::zero(2)));
  ubv extendedDenominator(right.getSignificand().append(ubv::zero(2)));

  resultWithRemainderBit<t> divided(fixedPointDivide<t>(extendedNumerator, extendedDenominator));
  

  bwt resWidth(divided.result.getWidth());
  ubv topBit(divided.result.extract(resWidth - 1, resWidth - 1));
  ubv nextBit(divided.result.extract(resWidth - 2, resWidth - 2));

  // Alignment of inputs means at least one of the two MSB is 1
  //  i.e. [1,2) / [1,2) = [0.5,2)
  // Top bit is set by the first round of the divide and thus is 50/50 1 or 0
  prop topBitSet(topBit.isAllOnes());
  INVARIANT(topBitSet || nextBit.isAllOnes());
  INVARIANT(topBitSet == (left.getSignificand() >= right.getSignificand()));
  
  // Re-align
  ubv alignedSignificand(conditionalLeftShiftOne<t>(!topBitSet, divided.result)); // Will not loose information

  // Subtract up exponents
  // Optimisation : use the if-then-lazy-else to avoid dividing for underflow and overflow
  //                subnormal / greater-than-2^sigwidth does not need to be evaluated
  sbv alignedExponent(expandingSubtractWithBorrowIn<t>(left.getExponent(),right.getExponent(), !topBitSet));

  // Create the sticky bit, it is important that this is after alignment
  ubv finishedSignificand(alignedSignificand | ubv(divided.remainderBit).extend(resWidth - 1));
  
  // Put back together
  unpackedFloat<t> divideResult(divideSign, alignedExponent, finishedSignificand);

  sbv min(unpackedFloat<t>::minSubnormalExponent(format));
  sbv max(unpackedFloat<t>::maxNormalExponent(format));
  sbv divideResultExponentUpperBound(expandingSubtractWithBorrowIn<t>(max, min, false));
  sbv divideResultExponentLowerBound(expandingSubtractWithBorrowIn<t>(min, max, true));  // -1 for renormalisation of the top bit

  POSTCONDITION(divideResult.wellFormed(divideResultExponentLowerBound, divideResultExponentUpperBound));

  // A brief word about formats.
  // Most operations adding one bit to the exponent format is enough to represent the result.
  // +1 is sufficient in almost all cases.  However:
  //    very large normal / very small subnormal
  // can have an exponent greater than very large normal * 2 ( + 1)
  // because the exponent range is asymmetric with more subnormal than normal.
  
  return divideResult;
 }

 template <class t>
  unpackedFloat<t> falseDivide (const typename t::fpt &format,
				       const unpackedFloat<t> &left,
				       const unpackedFloat<t> &right,
               const typename t::prop &denorm) {
  typedef typename t::bwt bwt;
  typedef typename t::prop prop;
  typedef typename t::ubv ubv;
  typedef typename t::sbv sbv;
  //typedef typename t::fpt fpt;

  PRECONDITION(left.valid(format));
  PRECONDITION(right.valid(format));

  // Compute sign
  prop divideSign(left.getSign() ^ right.getSign());

  // Subtract the significands instead of a proper divison
  sbv zeroShift = sbv::zero(left.getSignificand().getWidth());
  prop leftSubnorm(left.inSubnormalRange(format, prop(true)));
  ubv leftShift = ITE(denorm && leftSubnorm, left.getSubnormalAmount(format).matchWidth(zeroShift), zeroShift);
  ubv rightShift = ITE(denorm && right.inSubnormalRange(format, prop(true)), right.getSubnormalAmount(format).matchWidth(zeroShift), zeroShift);

  // Subnormals are treated as normals with an additional exponent bit, we need to recover the raw value
  // then prefix the left with 10 and the right with 00 (which also ensures the output always has a 1 in one of the first two bits)
  ubv denormLeft(ubv::one(1).append((left.getSignificand() >> leftShift).extend(1)));
  ubv denormRight((right.getSignificand() >> rightShift).extend(2));

  ubv result(denormLeft - denormRight);

  // The rest is (mostly) the same, but without the remainder
  bwt resWidth(result.getWidth());
  ubv topBit(result.extract(resWidth - 1, resWidth - 1));
  ubv nextBit(result.extract(resWidth - 2, resWidth - 2));

  prop topBitSet(topBit.isAllOnes());
  INVARIANT(topBitSet || nextBit.isAllOnes());

  ubv alignedSignificand(conditionalLeftShiftOne<t>(!topBitSet, result));
  sbv alignedExponent(expandingSubtractWithBorrowIn<t>(left.getExponent(),right.getExponent(), !topBitSet));
  unpackedFloat<t> divideResult(divideSign, alignedExponent, alignedSignificand);

  sbv min(unpackedFloat<t>::minSubnormalExponent(format));
  sbv max(unpackedFloat<t>::maxNormalExponent(format));
  sbv divideResultExponentUpperBound(expandingSubtractWithBorrowIn<t>(max, min, false));
  sbv divideResultExponentLowerBound(expandingSubtractWithBorrowIn<t>(min, max, true));

  POSTCONDITION(divideResult.wellFormed(divideResultExponentLowerBound, divideResultExponentUpperBound));
  return divideResult;
 }


// Put it all together...
template <class t>
  unpackedFloat<t> divide (const typename t::fpt &format,
			   const typename t::rm &roundingMode,
			   const unpackedFloat<t> &left,
			   const unpackedFloat<t> &right) {
  //typedef typename t::bwt bwt;
  //typedef typename t::prop prop;
  //typedef typename t::ubv ubv;
  //typedef typename t::sbv sbv;

  PRECONDITION(left.valid(format));
  PRECONDITION(right.valid(format));

  unpackedFloat<t> divideResult(arithmeticDivide(format, left, right));
  
  unpackedFloat<t> roundedDivideResult(rounder(format, roundingMode, divideResult));
  
  unpackedFloat<t> result(addDivideSpecialCases(format, left, right, roundedDivideResult.getSign(), roundedDivideResult));

  POSTCONDITION(result.valid(format));

  return result;
 }

 template <class t>
  floatWithStatusFlags<t> divide_flagged (const typename t::fpt &format,
			   const typename t::rm &roundingMode,
			   const unpackedFloat<t> &left,
			   const unpackedFloat<t> &right) {

  PRECONDITION(left.valid(format));
  PRECONDITION(right.valid(format));

  unpackedFloat<t> divideResult(arithmeticDivide(format, left, right));
  
  floatWithStatusFlags<t> roundedDivideResult(rounder_flagged(format, roundingMode, divideResult));
  
  floatWithStatusFlags<t> result_flagged(addDivideSpecialCases_flagged(format, left, right, roundedDivideResult.getSign(), roundedDivideResult));

  POSTCONDITION(result_flagged.valid(format));

  return result_flagged;
 }

 template <class t>
  floatWithStatusFlags<t> falseDivide_flagged (const typename t::fpt &format,
			   const typename t::rm &roundingMode,
			   const unpackedFloat<t> &left,
			   const unpackedFloat<t> &right,
         const typename t::prop &denorm) {

  PRECONDITION(left.valid(format));
  PRECONDITION(right.valid(format));

  unpackedFloat<t> divideResult(falseDivide(format, left, right, denorm));
  
  floatWithStatusFlags<t> roundedDivideResult(rounder_flagged(format, roundingMode, divideResult));
  
  floatWithStatusFlags<t> result_flagged(addDivideSpecialCases_flagged(format, left, right, roundedDivideResult.getSign(), roundedDivideResult));

  POSTCONDITION(result_flagged.valid(format));

  return result_flagged;
 }


}

#endif
