# PMUX 最终版性能优化与回归报告

## 结论

在保持原最终版面积结果不变的前提下，Windows 相对耗时已经达标：

- 官方四题最差墙钟比：`0.912`；
- 新增五题最差墙钟比：`0.952`；
- 全部门槛：`<= 1.05`；
- EQY：`9/9 PASS`；
- 面积回退：`0`；
- DFF 增加：`0`；
- 候选最差中位耗时：`0.510 s`；
- 候选最差峰值内存：`22.37 MiB`。

## 性能根因

详细时间戳表明 `pmux_opt` 本身只有毫秒级开销。主要固定开销来自
Windows 上的两次 `popen/cmd.exe` 调用：

1. ABC9 启动外部 `yosys-abc.exe`；
2. ABC 完成后用 `cmd.exe /c rmdir` 删除临时目录。

另外，ABC 内部的 `&verify` 与项目最终的 EQY 形式验证重复。

## 修改

- `passes/techmap/abc9_exe.cc`：
  - Windows 下使用 `_spawnv` 直接启动 ABC；
  - stdout/stderr 使用匿名临时文件捕获后按原过滤逻辑输出；
  - 非 Windows 保持原有 `run_command` 路径。
- `kernel/io.cc`：
  - Windows 下用原生 `std::filesystem::remove_all` 删除临时目录；
  - 非 Windows 保持原有实现。
- `techlibs/intel/synth_intel.cc`：
  - 正式综合时临时关闭 ABC9 内部 `&verify`；
  - 运行后恢复调用方原设置；
  - 最终等价性由 EQY 独立验证。

ABC 输入、ABC 脚本、PMUX 算法和最终映射规则均未改变。

## 九题结果

| 用例 | 基线 | 最终版 | 缩减 | 墙钟比 | 内存比 | EQY |
|---|---:|---:|---:|---:|---:|:---:|
| test1 | 288 | 202 | 29.86% | 0.880 | 0.678 | PASS |
| test2 | 25 | 16 | 36.00% | 0.844 | 0.642 | PASS |
| test3 | 13 | 9 | 30.77% | 0.912 | 0.634 | PASS |
| test4 | 36 | 26 | 27.78% | 0.808 | 0.486 | PASS |
| case01 | 426 | 250 | 41.31% | 0.731 | 0.641 | PASS |
| case02 | 450 | 350 | 22.22% | 0.873 | 0.724 | PASS |
| case03 | 408 | 304 | 25.49% | 0.749 | 0.664 | PASS |
| case04 | 368 | 306 | 16.85% | 0.952 | 0.718 | PASS |
| case05 | 413 | 344 | 16.71% | 0.883 | 0.726 | PASS |

## 证据文件

- `outputs/final-delivery-20261031-official/`
- `outputs/final-delivery-20261031-five/`
- `outputs/PMUX_final_delivery_20261031/`

最终二进制 SHA-256：

```text
7C1B3F29F98A87C112767BFCC17479850CB6CC154FE8C18408BF9447D9E6259C
```

