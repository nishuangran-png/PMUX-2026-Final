# PMUX Optimizer for Yosys

面向国产 FPGA 综合流程的 PMUX 结构优化插件，基于官方 Yosys v0.69：

```text
commit: 9f75ca1f9834a39a863915b5dae0c7b1e33533bc
```

插件注册 Tcl/Pass 命令 `pmux_opt`，用于识别和重构：

- `$pmux` 选择结构；
- priority MUX 链；
- 稠密译码选择器；
- 对称双 PMUX；
- 稀疏部分更新；
- 常量 ROM；
- 可折叠的 LUT / DFF 使能逻辑。

## 文件说明

```text
src/yosys-069/passes/pmux/              PMUX 优化算法
src/yosys-069/passes/techmap/abc9_exe.cc Windows ABC 启动优化
src/yosys-069/kernel/io.cc               Windows 临时目录清理优化
src/yosys-069/kernel/yosys.cc            可移动 ABC 路径选择
src/yosys-069/techlibs/intel/            Cyclone IV 映射辅助文件
patches/yosys-069/                      Yosys 流程集成补丁
scripts/install_final.sh                 Linux/macOS 构建入口
examples/official/                      官方四题
examples/five/                          新增五题
validation/                             面积、耗时、内存与 EQY 证据
```

`src/` 中只保存本项目的增量/替换文件，不包含完整 Yosys 源码。

## 构建

先获取官方 Yosys v0.69，并初始化 submodule：

```bash
git clone https://github.com/YosysHQ/yosys.git yosys-0.69
cd yosys-0.69
git checkout 9f75ca1f9834a39a863915b5dae0c7b1e33533bc
git submodule update --init --recursive
cd ..
```

在包含本仓库 `README.md` 的目录运行：

```bash
bash scripts/install_final.sh /path/to/yosys-0.69
```

构建结果：

```text
/path/to/yosys-0.69/build-final/yosys
```

## 综合

```tcl
read_verilog case.v;
synth_intel -family cycloneiv -top module_name;
stat
```

只执行 PMUX Pass：

```tcl
read_verilog case.v;
hierarchy -top module_name;
proc;
opt;
pmux_opt;
stat
```

## 验证

- 官方四题平均面积缩减：`31.10%`
- 新增五题平均面积缩减：`24.52%`
- 九题 EQY：`9/9 PASS`
- 最差相对耗时：`0.952`
- 最差相对内存：`0.726`

Yosys 代码遵循上游 ISC License；ABC 遵循其随附许可证，分别见：

```text
LICENSE_YOSYS.txt
LICENSE_ABC.txt
```

