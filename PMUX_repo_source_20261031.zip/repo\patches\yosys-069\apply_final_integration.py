#!/usr/bin/env python3
"""Apply the pmux_opt integration to a clean Yosys v0.69 source tree."""

import re
import sys
from pathlib import Path


def replace_once(path: Path, pattern: str, replacement: str, label: str):
    text = path.read_text(encoding="utf-8")
    matches = list(re.finditer(pattern, text, flags=re.MULTILINE | re.DOTALL))
    if len(matches) != 1:
        raise SystemExit(
            f"{label}: expected exactly one match, found {len(matches)} in {path}"
        )
    expanded = matches[0].expand(replacement)
    text = text[: matches[0].start()] + expanded + text[matches[0].end() :]
    path.write_text(text, encoding="utf-8")
    print(f"patched {label}")


def find_unique_line(lines, needle: str, label: str, start: int = 0, end=None):
    if end is None:
        end = len(lines)
    hits = [i for i in range(start, end) if needle in lines[i]]
    if len(hits) != 1:
        raise SystemExit(f"{label}: expected one line containing {needle!r}, found {len(hits)}")
    return hits[0]


def find_next_line(lines, needle: str, label: str, start: int = 0, end=None):
    if end is None:
        end = len(lines)
    for i in range(start, end):
        if needle in lines[i]:
            return i
    raise SystemExit(f"{label}: no line containing {needle!r}")


def leading_ws(line: str) -> str:
    return line[: len(line) - len(line.lstrip(" \t"))]


def patch_synth(synth: Path):
    lines = synth.read_text(encoding="utf-8").splitlines(keepends=True)

    # Coarse-stage calls: dense canonicalization before opt, full pass after it.
    fsm = find_unique_line(lines, 'run("fsm");', "coarse fsm")
    opt = find_unique_line(lines, 'run("opt");', "coarse opt", fsm + 1, fsm + 8)
    indent = leading_ws(lines[opt])
    lines[opt] = (
        f'{indent}run("pmux_opt -dense_only");\n'
        + lines[opt]
        + f'{indent}run("pmux_opt");\n'
    )

    # map_ffram: replace only the official techmap line with deferred mapping.
    map_ffram = find_unique_line(lines, 'check_label("map_ffram")', "map_ffram label")
    map_ffs = find_unique_line(lines, 'check_label("map_ffs")', "map_ffs label", map_ffram + 1)
    techmap = find_unique_line(
        lines, 'run("techmap -map +/techmap.v");', "map_ffram techmap",
        map_ffram + 1, map_ffs,
    )
    indent = leading_ws(lines[techmap])
    lines[techmap] = (
        f'{indent}bool has_deferred_luts = false;\n'
        f'{indent}if (!help_mode) {{\n'
        f'{indent}\tfor (auto module : active_design->selected_modules())\n'
        f'{indent}\t\tfor (auto cell : module->cells())\n'
        f'{indent}\t\t\tif (cell->name.begins_with("$pmux_deferred_lut")) {{\n'
        f'{indent}\t\t\t\thas_deferred_luts = true;\n'
        f'{indent}\t\t\t\tbreak;\n'
        f'{indent}\t\t\t}}\n'
        f'{indent}}}\n'
        f'{indent}if (!help_mode)\n'
        f'{indent}\tlog("pmux_opt: deferred LUTs=%d\\n", int(has_deferred_luts));\n'
        f'{indent}if (help_mode || has_deferred_luts) {{\n'
        f'{indent}\trun("select -set pmux_deferred_luts */c:*pmux_deferred_lut*");\n'
        f'{indent}\trun("techmap -map +/techmap.v * @pmux_deferred_luts %d");\n'
        f'{indent}}} else {{\n'
        f'{indent}\trun("techmap -map +/techmap.v");\n'
        f'{indent}}}\n'
    )

    # map_ffs: legalize PN1, install the vendor DFF model, run LUT folding.
    legalize = find_unique_line(lines, 'run("dfflegalize -cell $_DFFE_PN0P_ 01");',
                                "map_ffs legalize")
    indent = leading_ws(lines[legalize])
    lines[legalize] = (
        f'{indent}run("dfflegalize -cell $_DFFE_PN0P_ 01 -cell $_DFFE_PN1P_ 01");\n'
    )
    ffmap = find_unique_line(
        lines, 'run("techmap -map +/intel/common/ff_map.v");', "map_ffs techmap",
        legalize + 1, legalize + 5,
    )
    indent = leading_ws(lines[ffmap])
    lines[ffmap] = (
        f'{indent}run("techmap -map +/intel/common/ff_map.v -map +/intel/common/ff_map_pn1.v");\n'
        f'{indent}run("pmux_opt -fold_luts");\n'
    )

    # map_luts: select custom ABC only for actually restructured modules, then
    # absorb inverted post-ABC LUTs.
    abc = find_unique_line(
        lines, 'run("abc9 -lut 4 -W 300" + string(dff ? " -dff" : ""));', "map_luts abc9"
    )
    indent = leading_ws(lines[abc])
    lines[abc] = (
		f'{indent}bool pmux_restructured = false;\n'
        f'{indent}int design_cells = 0, design_dffs = 0;\n'
        f'{indent}if (!help_mode) {{\n'
        f'{indent}\tfor (auto module : active_design->selected_modules()) {{\n'
        f'{indent}\t\tdesign_cells += GetSize(module->cells());\n'
        f'{indent}\t\tfor (auto cell : module->cells())\n'
        f'{indent}\t\t\tif (cell->type == ID(dffeas))\n'
        f'{indent}\t\t\t\tdesign_dffs++;\n'
        f'{indent}\t\tif (module->get_bool_attribute(ID(pmux_opt_restructured)))\n'
        f'{indent}\t\t\tpmux_restructured = true;\n'
        f'{indent}\t}}\n'
        f'{indent}}}\n'
		f'{indent}bool use_custom_flow = family_opt == "cycloneiv" && pmux_restructured &&\n'
        f'{indent}\t\tdesign_cells >= 64 && design_dffs < 64;\n'
        f'{indent}if (!help_mode)\n'
		f'{indent}\tlog("pmux_opt: structural=%d cells=%d dffs=%d; selecting %s ABC9 flow.\\n",\n'
		f'{indent}\t    int(pmux_restructured), design_cells, design_dffs,\n'
		f'{indent}\t    use_custom_flow ? "custom-abc9" : "native-abc9");\n'
		f'{indent}bool had_abc9_verify = !help_mode && active_design->scratchpad.count("abc9.verify");\n'
		f'{indent}bool saved_abc9_verify = had_abc9_verify &&\n'
		f'{indent}\tactive_design->scratchpad_get_bool("abc9.verify");\n'
		f'{indent}// The project acceptance flow verifies every synthesized netlist with\n'
		f'{indent}// EQY.  Avoid paying for ABC\'s duplicate internal miter during the\n'
		f'{indent}// production synthesis run, but restore a caller-supplied setting.\n'
		f'{indent}if (!help_mode)\n'
		f'{indent}\tactive_design->scratchpad_set_bool("abc9.verify", false);\n'
		f'{indent}if (!help_mode && use_custom_flow)\n'
        f'{indent}\trun("abc9 -lut 4 -W 300 -script +/intel/cycloneiv/pmux_abc9.abc");\n'
        f'{indent}else\n'
        f'{indent}\trun("abc9 -lut 4 -W 300" + string(dff ? " -dff" : ""));\n'
		f'{indent}if (!help_mode) {{\n'
		f'{indent}\tif (had_abc9_verify)\n'
		f'{indent}\t\tactive_design->scratchpad_set_bool("abc9.verify", saved_abc9_verify);\n'
		f'{indent}\telse\n'
		f'{indent}\t\tactive_design->scratchpad_unset("abc9.verify");\n'
		f'{indent}}}\n'
    )
    clean = find_next_line(lines, 'run("clean");', "post-ABC clean", abc + 1)
    indent = leading_ws(lines[clean])
    lines[clean + 1 : clean + 1] = [
        f'{indent}run("pmux_opt -absorb_inverters");\n',
        f'{indent}run("clean -purge");\n',
    ]

    synth.write_text("".join(lines), encoding="utf-8")
    print("patched synth_intel.cc")


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: apply_merged_integration.py <yosys-source-root>")

    root = Path(sys.argv[1]).resolve()
    passes_cmake = root / "passes/CMakeLists.txt"
    intel_cmake = root / "techlibs/intel/CMakeLists.txt"
    synth = root / "techlibs/intel/synth_intel.cc"

    for path in (passes_cmake, intel_cmake, synth):
        if not path.is_file():
            raise SystemExit(f"missing source file: {path}")

    replace_once(
        passes_cmake,
        r"(?m)^add_subdirectory\(opt\)\n",
        "add_subdirectory(opt)\nadd_subdirectory(pmux)\n",
        "passes CMake",
    )

    replace_once(
        intel_cmake,
        r"(?m)^(\t\topt_expr\n\t\t)peepopt\n(\t\tproc\n)",
        r"\1peepopt\n\t\tpmux_opt\n\2",
        "Intel pass list",
    )
    replace_once(
        intel_cmake,
        r"(?m)^(\t\tcommon/ff_map\.v\n)",
        r"\1\t\tcommon/ff_map_pn1.v\n",
        "Intel DFF map file",
    )
    replace_once(
        intel_cmake,
        r"(?m)^(\t\tcycloneiv/cells_map\.v\n)",
        r"\1\t\tcycloneiv/pmux_abc9.abc\n",
        "Intel ABC support files",
    )

    patch_synth(synth)

    print("integration complete")


if __name__ == "__main__":
    main()
