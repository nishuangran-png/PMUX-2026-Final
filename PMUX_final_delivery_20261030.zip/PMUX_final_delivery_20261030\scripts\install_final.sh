#!/usr/bin/env bash
# Install the final PMUX optimizer into a clean official Yosys v0.69 tree,
# then configure and build it. ABC9 is required; legacy ABC is not used.

set -euo pipefail

PACKAGE_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
YOSYS_SRC="${1:-}"

if [[ -z "$YOSYS_SRC" ]]; then
	echo "usage: bash scripts/install_final.sh /path/to/clean/yosys-v0.69"
	exit 2
fi
YOSYS_SRC="$(cd "$YOSYS_SRC" && pwd -P)"

expected_commit="9f75ca1f9834a39a863915b5dae0c7b1e33533bc"
actual_commit="$(git -C "$YOSYS_SRC" rev-parse HEAD 2>/dev/null || true)"
if [[ "$actual_commit" != "$expected_commit" ]]; then
	echo "ERROR: Yosys HEAD is '$actual_commit', expected $expected_commit"
	exit 1
fi

mkdir -p "$YOSYS_SRC/passes/pmux"
mkdir -p "$YOSYS_SRC/techlibs/intel/common"
mkdir -p "$YOSYS_SRC/techlibs/intel/cycloneiv"

cp "$PACKAGE_ROOT/src/yosys-069/passes/pmux/pmux_opt.cc" \
	"$YOSYS_SRC/passes/pmux/pmux_opt.cc"
cp "$PACKAGE_ROOT/src/yosys-069/passes/pmux/CMakeLists.txt" \
	"$YOSYS_SRC/passes/pmux/CMakeLists.txt"
cp "$PACKAGE_ROOT/src/yosys-069/techlibs/intel/common/ff_map_pn1.v" \
	"$YOSYS_SRC/techlibs/intel/common/ff_map_pn1.v"
cp "$PACKAGE_ROOT/src/yosys-069/techlibs/intel/cycloneiv/pmux_abc9.abc" \
	"$YOSYS_SRC/techlibs/intel/cycloneiv/pmux_abc9.abc"

python3 "$PACKAGE_ROOT/patches/yosys-069/apply_final_integration.py" "$YOSYS_SRC"

cmake -S "$YOSYS_SRC" -B "$YOSYS_SRC/build-final" \
	-DCMAKE_BUILD_TYPE=Release \
	-DYOSYS_WITHOUT_SLANG=ON
cmake --build "$YOSYS_SRC/build-final" --target yosys --parallel "$(nproc)"

echo
echo "Final Yosys built at:"
echo "  $YOSYS_SRC/build-final/yosys"
