# PMUX Final Delivery

最终方案基于 Yosys 官方 v0.69：

```text
commit: 9f75ca1f9834a39a863915b5dae0c7b1e33533bc
```

## 组成

```text
src/yosys-069/passes/pmux/pmux_opt.cc
src/yosys-069/passes/pmux/CMakeLists.txt
src/yosys-069/techlibs/intel/common/ff_map_pn1.v
src/yosys-069/techlibs/intel/cycloneiv/pmux_abc9.abc
patches/yosys-069/apply_final_integration.py
scripts/install_final.sh
validation/
```

该版本：

- pass 编译进 Yosys 主程序；
- 不通过 `plugin -i` 加载；
- 使用完整 PMUX 二维矩阵转置；
- partial matrix 默认关闭；
- 统一使用 ABC9；
- 结构改写模块使用仓库内 `pmux_abc9.abc`；
- 未改写模块使用官方原生 ABC9；
- 不使用 legacy `abc`；
- 不读取测试名、文件名或模块名。

## 安装与构建

准备一个干净、已初始化 submodule 的官方 Yosys v0.69 源码树：

```bash
bash scripts/install_final.sh /path/to/yosys-v0.69
```

脚本会安装源码、执行结构化集成，并构建：

```text
/path/to/yosys-v0.69/build-final/yosys
```

## 最终综合命令

```tcl
read_verilog case.v;
synth_intel -family cycloneiv -top <top>;
stat
```

## 最终验证结果

新五题：

| case | baseline | final | reduction |
|---|---:|---:|---:|
| balanced | 426 | 250 | 41.31% |
| pipeline | 450 | 350 | 22.22% |
| crossbar | 408 | 304 | 25.49% |
| feedback | 368 | 306 | 16.85% |
| nested | 413 | 344 | 16.71% |

新五题平均：`24.52%`

原四题：

| case | baseline | final | reduction |
|---|---:|---:|---:|
| test1 | 288 | 202 | 29.86% |
| test2 | 25 | 16 | 36.00% |
| test3 | 13 | 9 | 30.77% |
| test4 | 36 | 26 | 27.78% |

原四题平均：`31.10%`

九题逐题平均：`27.44%`

约束状态：

- 面积回退：0
- DFF 增加：0
- 新五题 EQY：5/5 PASS
- 最大墙钟比：1.000
- 最大 RSS 比：0.911

## 最终 ABC9 脚本

`pmux_abc9.abc` 内容：

```text
&scorr
&sweep
&dc2
&dch -f -r
&syn2 -m -R 10
&if -W 300 -a -v
&mfs
```

## 注意

- 本包不包含 legacy ABC 路径。
- partial matrix 和 deep PMUX lowering 属于实验性开关，默认不启用。
- 提交正式结果时只使用 `validation/` 中的最终版本数据。
